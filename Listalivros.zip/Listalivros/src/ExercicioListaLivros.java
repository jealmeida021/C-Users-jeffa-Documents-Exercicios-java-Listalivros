import java.util.List;

public class ExercicioListaLivros {

    //exibirLivro(Livro livro): exibe os detalhes de um livro (título, autor, pontuação).
    public void exibirLivro(Livro livro) {
        System.out.println("Detalhes do livro : ");
        System.out.println("Título : " + livro.getTitulo());
        System.out.println("Autor : " + livro.getAutor());
        System.out.println("Pontuação : " + livro.getPontuacao());
    }
// exibirLivros(List<Livro> livros): exibe os detalhes de todos os livros na lista.

    public void exibirLivros(List<Livro> livros) {
        //Iterar
        for (Livro vlivro : livros) {
            exibirLivro(vlivro);
        }
    }

    //buscarLivroPorTitulo(List<Livro> livros, String titulo):
    // recebe o título de um livro e retorna o livro correspondente da lista, ou null se não for encontrado.

    public Livro buscarLivroPorTitulo(List<Livro>livros,String titulo){
                  for (Livro livro : livros) {
                if (livro.getTitulo().equals(titulo)) {
                    return livro;
                }
            }
            return null;
        }

    }


