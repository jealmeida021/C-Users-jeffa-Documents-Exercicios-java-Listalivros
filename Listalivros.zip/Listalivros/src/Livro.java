import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Livro {
    private String titulo;
    private String autor;
    private double pontuacao;

    public Livro(String titulo, String autor, double pontuacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.pontuacao = pontuacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public double getPontuacao() {
        return pontuacao;
    }

    public void setTitulo(String titulo){
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setPontuacao(double pontuacao) {
        this.pontuacao = pontuacao;
    }

    
}
