import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<livro> livros = new ArrayList();

        int opcao = -1;

        while (opcao != 0) {
            System.out.println("Escolha uma opção:");
            System.out.println("1 - Adicionar novo livro");
            System.out.println("2 - Exibir o lista de livros");
            System.out.println("3 - buscar livro por título ");
            System.out.println("0 - Sair do programa");

            opcao = scanner.nextInt(); // consumir qubra linha

            switch (opcao) {
                case 1:
                    System.out.println("Digite o título do livro:");
                    String titulo = scanner.nextLine();

                    System.out.println("Digite o nome do Auto:");
                    String autor = scanner.nextLine();

                    System.out.println("Digite a pontuação do livro");
                    double pontuacao = scanner.nextDouble();

                    Livro livro = new Livro(titulo, autor, pontuacao);
                    livros.add(livro);
                    break;

                case 2:
                    if (livros.isEmpty()) {
                        System.out.println("Não há livros cadastrados ");
                    } else {
                        exibirLivros(livros);
                    }
                    break;
            }

            case 3:
                if (livros.isEmpty()) {
                    System.out.println("Não ha livros cadastrados.");
                } else {
                    System.out.println("Digite o título do livro:");
                    titulo = scanner.nextLine();

                    Livro livroEncontrado = buscarLivroPorTitulo(livros, titulo);

                    if (livroEncontrado == null) {
                        System.out.println(("livro não encontrado"));
                    } else {
                        exibirLivros(livroEncontrado);
                    }
                    break;
                }

            case 0:
                System.out.println("Finalizando o programa.");
                break;
            default:
                System.out.println("Opçõa invalida");

        }
    }
    scanner.close();

        //Instanciado com metodo
        ExercicioListaLivros exercicioListaLivros = new ExercicioListaLivros();
        Livro livro1 = new Livro("Logica de Programaçao","Jose Dias",10);
        Livro livro2 = new Livro( "Algoritomos", "Joao Santos",9);
        Livro livro3 = new Livro("Java", "Paulo ", 9.5);

        //Métodos de exibição do livro
        exercicioListaLivros.exibirLivro(livro1);
        System.out.println();
        exercicioListaLivros.exibirLivro(livro2);
        System.out.println();
        exercicioListaLivros.exibirLivro(livro3);
        System.out.println("");

        // Colection list
        List<Livro> listaDeLivros = new ArrayList<>();
        listaDeLivros.add(livro1);
        listaDeLivros.add(livro2);
        listaDeLivros.add(livro3);
        System.out.println("");
        exercicioListaLivros.exibirLivros(listaDeLivros);



    private static void exibirLivros(List<livro> livros) {
    }
}
